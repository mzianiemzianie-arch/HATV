export const environment = {
    apiKey: 'YOUR_API_KEY_HERE',
    baseUrl: 'https://api.themoviedb.org/3'
};
